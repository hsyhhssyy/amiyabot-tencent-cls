请帮我写一个logging.Handler的实现
从loglevel(message,extra={"message_data":data})
这样的调用中,提取出
message和extra
并对其进行处理(发送到某个对象存储,具体省略)


python中某个函数能否获取其调用者的某个局部变量或者某个调用者的参数

请使用inspect一轮按照堆栈帧向上找到第一个参数包含Message(一个已引入的类)的调用者并返回他的这个参数供我使用


我有一个logging.handler他的emit原始代码如下

def emit(self, record):
    data = get_frame_data(record)
    thread = threading.Thread(target=upload_log, args=(self,record,data))
    thread.daemon = True
    thread.start()

现在我想做如下改进
1. 每次提交都创建一个新线程开销太大，能否改为使用一个线程安全的队列，emit入队，然后该线程循环出队执行上传
2. 因为上传可能出错，因此每次入队的时候需要检查该线程是否正常存活，如果不存活则需要重启线程
3. 因为现在上传有延迟，因此在emit就需要确定时间戳并保存