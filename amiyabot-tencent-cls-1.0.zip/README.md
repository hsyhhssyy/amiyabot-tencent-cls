# 腾讯云日志服务CLS接入

**该插件需要兔兔版本至少6.4.5，该版本还未发布，不满足版本的情况下安装该插件无效。**

如下图所示，最终日志会通过level,app_id,channel_id,user_id,content几个字段上传到[腾讯云日志服务CLS](https://cloud.tencent.com/document/product/614/11254)中。

![例子](https://raw.githubusercontent.com/hsyhhssyy/amiyabot-tencent-cls/master/images/image.png)

提供代码以接入腾讯的CLS服务，你需要在插件配置中填写自己的Key等内容。

## 鸣谢

> [插件项目地址:Github](https://github.com/hsyhhssyy/amiyabot-tencent-cls/)

> [遇到问题可以在这里反馈(Github)](https://github.com/hsyhhssyy/amiyabot-tencent-cls/issues/new/)

|  版本   | 变更  |
|  ----  | ----  |
| 1.0  | 内部测试版本 |