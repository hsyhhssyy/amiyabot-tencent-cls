# 腾讯云日志服务CLS接入

![Alt text](images/image.png)

提供代码以接入腾讯的CLS服务，你需要在插件配置中填写自己的Key等内容。